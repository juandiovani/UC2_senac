const idadeH = 17
const idadeC = idadeH*7

console.log("Se vc fosse uma cachorro, o que e imposível,você teria", idadeC,"anos!!", " seu asno!!")

const v1 = 60
const v2 = 45

//comparação a seguir:
const comparação = v1 === v2
console.log9(comparação) 

//diferença a seguir:
const diferença = v1 !== v2 
console.log(diferença)

//maior a seguir
const maior = v1 > v2
console.log(maior)

//menor a seguir:
const menor = v1 < v2
console.log(menor)

//maior igual a seguir:
const maiorIgual = v1 >= v2
console.log(maiorIgual)

//menor igual a seguir:
const menorIgual = v1 <= v2
console.log(menorIgual)

//igualdade
"1" === "2" //false, pois são diferente
"2" === "2" //true, pois são iguais
2 !== "2" // true, são diferentes

const condicao = 1 === 2
//o valor que sai da comparação pode ser guardado em uma variável nesse caso, condição === false

//diferença
"1" !== "2" //true, são diferentes
"2" !== "2" //false, são iguais 
2 !== "2" //false, são diferentes

1 >= 2 // false, pq 1 é menor q 2
2 >= 2 // false, pq são iguais
3 >= 2 // true, pois 3 é maior q 2

1 >= 2 // false, pq 1 é menor q 2
2 >= 2 // true, pois são iguais
3 >= 2 // true, pq 3 é maior q 2

1 < 2 // true, pq 1 é menor q 2
2 < 2 // false, pq são iguais
3 < 2 // false, pois 3 é maior q 2

1 <= 2 // false, pq 1 é menor q 2
2 <= 2 // true, pois são iguais
3 <= 2 // true, pq 3 é maior q 2

verificando = (5 < 3 )
console.log("a resposta é: ",verificando)


