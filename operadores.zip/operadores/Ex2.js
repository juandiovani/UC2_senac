const nota1 = 12
const nota2 = 4
const nota3 = 20

const média = (nota1 + nota2 + nota3)/3

console.log("a média de suas notas é: ", média)

const n1 = 2.5
const n2 = 4
const n3 = 6

const João = (n1 + n2 + n3)/3
console.log("a média de João é: ",João)

const N1 = 7.5
const N2 = 4.8
const N3 = 6.3

const Robersvaldo = (N1 + N2 + N3)/3
console.log("a média de Robersvaldo é: ",Robersvaldo)

const nt1 = 3.5
const nt2 = 8
const nt3 = 6

const Maria = (nt1 + nt2 + nt3)/3
console.log("a média de Maria é: ",Maria)







