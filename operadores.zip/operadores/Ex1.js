/*const  Nome="Neco "
Idade =6
aprenderFalar = true
console.log("Meu cachorro",Nome,"tem",Idade,"anos. ele pode falar?",aprenderFalar)

const Sabor="lombo"
Valor=30.00
pizzavoa=false 
console.log("Pizza de",Sabor,"R$",Valor,"ela voa?",pizzavoa )

 const Nome1="JD"
 passosdedança= 19
 estadançando= true 
 console.log("O",Nome1,"ja aprendeu",passosdedança,"passos!Ele está dançando agora?",estadançando)

 console.log(typeof nome)
 console.log(typeof passosdedança)
 console.log(typeof estádançando)*/
 
 const numeroInicial = 120
 const multiplicador = 3
 const divisor = 5
 //passo 1:
 const mult = numeroInicial*multiplicador
 console.log("a multiplicação é: ", mult)

 //passo 2:
 const div = mult/divisor 
 console.log("a divisão é: ", div)

 //passo 3:
 const rest = div%7
 console.log("o resto da divisão do resultado anterior é: ", rest)

 //passo 4:
 const soma = rest + 10 
 console.log("a soma é:  ", soma)

 //passo 5:
 const multiplicação = 3*numeroInicial - soma 

 console.log("a multiplicação é: ", multiplicação)
