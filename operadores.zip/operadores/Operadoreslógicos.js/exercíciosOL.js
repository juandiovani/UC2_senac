// caso 1
/// =================================================
// variáveis
let idade = 20                  // a idade da pessoa
let assinaturaPaga = true       // se tem assinatura paga ou não

// Checando as condições:
let podeEntrar = (idade >= 18) && (assinaturaPaga == true)

// Resultado:
console.log(podeEntrar) // true se a peesoa pode entrar, e false se não

// caso 2
let idadeNova = 16
let documentação = true 
const compraBebida = (idadeNova >= 18) && (documento == true)
console.log(compraBebida)

// caso 3
let valorCompra = 269
let clienteVip = true

const cupom = (valorCompra >= 100) || (clienteVip == true)
console.log(cupom)

// caso 4
const idade2 = 65
let deficiencia = false

const vaga = (idade2 >= 60) || (deficiencia == true)
console.log(vaga)

// caso 5

 const controle = true 
const tvConectada = false

let jogarTV = (controle == true) || (tvConectada == true)
console.log(jogarTV)

// caso 6
let login = true
let permissão = true

let terAutorização = (login == true) || (permissão == true)
console.log(permissão)

//desafio caso 7

const NF = 8
const NR = 9.0

let t1 = 6
let t2 = 5
let t3 = 9

const aprovação1 = NF > 7
console.log("na primeira aprovação, você passou", aprovação)

const aprovação2 = NF <= 7 && (NR >= 8 && (t1 > 6) && (t2 > 6) && (t3 < 6) || (t1 < 6) && (t2 > 6) && (t3 > 6) || (t1 > 6) && (t2<=6) && (t3 > 6))
console.log("você passou na segunda aprovação", aprovação2)

const aprovação3 = NF > 7 && MR < 8 && ((t1 < 6)&&(t2 > 6) && (t3 > 6) ||)
 
// Caso 7

// Entrada de dados (variáveis)
let NF1 = 6 // Exemplo: Nota Final
let NR1 = 8 // Exemplo: Nota recuperação
let T1 = 7 // Nota Trabalho 1
let T2 = 9 // Nota do Trabalho 2
let T3 = 5 // Nota do trabalho 3

// Lógica de aprovação :)
let trabalhosAprovados =(T1 > 6) + (T2 > 6) + (T3 > 6) // Soma dos trabalhos aprovados

// Juntando as considerações do problema
let aprovado = (NF > 7) || (NR >= 8 && trabalhosAprovados >= 2)
console.log(aprovado) // Exibe true (aprovado) ou false (reprovado)

// caso 8
let senhas = true // a pessoa tem senha?
let alcanse = true // a pessoa tem alcance?

let acessos = (senhas === true) && (alcanse === true)
console.log("téras acesso", acessos)

//caso 9
let renda = 1400
let nomeLimpo = false

let fazerEmprestimo = (renda > 2000) && (nomeLimpo == true)
console.log("pode fzr empréstimo?", fazerEmprestimo)

