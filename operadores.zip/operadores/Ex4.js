const nome = "Kratos"
const idade = "45"

const maior = true 

 let diferença = 2050 - 2025

 idade = anoAtual - nascimento 

  idadeFutura = idade + diferença 
 
 console.log("A sua idade atual é: ", idade, "seu nome é ", nome, "ele é de maior(", maior, ")", "ele terá", idadeFutura, "anos em 2050");
 

