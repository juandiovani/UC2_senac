function verificarChuva(){
    let tempo = prompt("Como está o tempo?")
     if(tempo === "chuvoso" ){
}else{     
   alert("Leve um guarda-chuva!")

}

}