const array = []
array[0] = 
function novaArray(a, b){
       return (a)


}  
